module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../../../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 5);
/******/ })
/************************************************************************/
/******/ ({

/***/ "./components/IdSearch/IdSearch.module.css":
/*!*************************************************!*\
  !*** ./components/IdSearch/IdSearch.module.css ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

// Exports
module.exports = {
	"background": "IdSearch_background__3cE0k"
};

/***/ }),

/***/ "./components/IdSearch/index.js":
/*!**************************************!*\
  !*** ./components/IdSearch/index.js ***!
  \**************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _IdSearch_module_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./IdSearch.module.css */ "./components/IdSearch/IdSearch.module.css");
/* harmony import */ var _IdSearch_module_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_IdSearch_module_css__WEBPACK_IMPORTED_MODULE_1__);
var _jsxFileName = "C:\\Users\\tallm\\Desktop\\DIG4503\\lab9\\components\\IdSearch\\index.js";

var __jsx = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement;


class IdSearch extends react__WEBPACK_IMPORTED_MODULE_0___default.a.Component {
  readId(event) {
    event.preventDefault();
    let pokemonId = document.querySelector("#id"); //need to figure out how to patch api

    fetch("api/pokemon/id/" + pokemonId.value).then(res => {
      return res.json();
    }).then(processed => {
      let outputArea = document.querySelector("#reportingArea");

      if (processed.error) {
        outputArea.innerHTML = processed.error;
      } else {
        outputArea.innerHTML = processed.name;
        /*
                    outputArea.innerHTML = processed.id+ ": "+ processed.name + " : "+ processed.typeList;
                    */
      }
    });
  }

  render() {
    return __jsx("div", {
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 37,
        columnNumber: 12
      }
    }, __jsx("body", {
      className: _IdSearch_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.background,
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 38,
        columnNumber: 16
      }
    }, __jsx("h2", {
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 39,
        columnNumber: 17
      }
    }, "id"), __jsx("form", {
      className: _IdSearch_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.form,
      onSubmit: this.readId,
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 40,
        columnNumber: 17
      }
    }, __jsx("input", {
      id: "id",
      type: "text",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 41,
        columnNumber: 20
      }
    }), __jsx("button", {
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 42,
        columnNumber: 20
      }
    }, "Submit"))));
  }

}

/* harmony default export */ __webpack_exports__["default"] = (IdSearch);

/***/ }),

/***/ "./components/NameSearch/NameSearch.module.css":
/*!*****************************************************!*\
  !*** ./components/NameSearch/NameSearch.module.css ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

// Exports
module.exports = {
	"background": "NameSearch_background__1bPy0"
};

/***/ }),

/***/ "./components/NameSearch/index.js":
/*!****************************************!*\
  !*** ./components/NameSearch/index.js ***!
  \****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _NameSearch_module_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./NameSearch.module.css */ "./components/NameSearch/NameSearch.module.css");
/* harmony import */ var _NameSearch_module_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_NameSearch_module_css__WEBPACK_IMPORTED_MODULE_1__);
var _jsxFileName = "C:\\Users\\tallm\\Desktop\\DIG4503\\lab9\\components\\NameSearch\\index.js";

var __jsx = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement;


class NameSearch extends react__WEBPACK_IMPORTED_MODULE_0___default.a.Component {
  //Create function that Create a function to be called when the user clicks on the <button> in the ID form, uses fetch(), and updates the reporting area
  readName(event) {
    event.preventDefault();
    let pokemonName = document.querySelector("#name"); //need to figure out how to patch api

    fetch("api/pokemon/name/" + pokemonName.value).then(res => {
      return res.json();
    }).then(processed => {
      let outputArea = document.querySelector("#reportingArea");

      if (processed.error) {
        outputArea.innerHTML = processed.error;
      } else {
        /*
        outputArea.innerHTML = processed.name + ": "+ processed.id + " : "+ processed.typeList;
        */
        outputArea.innerHTML = processed.name;
      }
    });
  }

  render() {
    return __jsx("div", {
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 32,
        columnNumber: 13
      }
    }, __jsx("body", {
      className: _NameSearch_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.background,
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 33,
        columnNumber: 17
      }
    }, __jsx("h2", {
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 34,
        columnNumber: 18
      }
    }, "Name"), __jsx("form", {
      onSubmit: this.readName,
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 35,
        columnNumber: 18
      }
    }, __jsx("input", {
      id: "name",
      type: "text",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 36,
        columnNumber: 21
      }
    }), __jsx("button", {
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 37,
        columnNumber: 21
      }
    }, "Submit"))));
  }

}

/* harmony default export */ __webpack_exports__["default"] = (NameSearch);

/***/ }),

/***/ "./components/TypeSearch/TypeSearch.module.css":
/*!*****************************************************!*\
  !*** ./components/TypeSearch/TypeSearch.module.css ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

// Exports
module.exports = {
	"background": "TypeSearch_background__1u5QL"
};

/***/ }),

/***/ "./components/TypeSearch/index.js":
/*!****************************************!*\
  !*** ./components/TypeSearch/index.js ***!
  \****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _TypeSearch_module_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./TypeSearch.module.css */ "./components/TypeSearch/TypeSearch.module.css");
/* harmony import */ var _TypeSearch_module_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_TypeSearch_module_css__WEBPACK_IMPORTED_MODULE_1__);
var _jsxFileName = "C:\\Users\\tallm\\Desktop\\DIG4503\\lab9\\components\\TypeSearch\\index.js";

var __jsx = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement;


class TypeSearch extends react__WEBPACK_IMPORTED_MODULE_0___default.a.Component {
  readId(event) {
    event.preventDefault();
    let pokemonType = document.querySelector("#type"); //need to figure out how to patch api

    fetch("api/pokemon/typeList/" + pokemonType.value).then(res => {
      return res.json();
    }).then(processed => {
      let outputArea = document.querySelector("#reportingArea");

      if (processed.error) {
        outputArea.innerHTML = processed.error;
      } else {
        outputArea.innerHTML = processed.name;
        /*
                    outputArea.innerHTML = processed.id+ ": "+ processed.name + " : "+ processed.typeList;
                    */
      }
    });
  }

  render() {
    return __jsx("div", {
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 35,
        columnNumber: 12
      }
    }, __jsx("body", {
      className: _TypeSearch_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.background,
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 36,
        columnNumber: 16
      }
    }, __jsx("h2", {
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 37,
        columnNumber: 17
      }
    }, "Pokemon Type"), __jsx("form", {
      onSubmit: this.readType,
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 38,
        columnNumber: 17
      }
    }, __jsx("input", {
      id: "type",
      type: "text",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 39,
        columnNumber: 20
      }
    }), __jsx("button", {
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 40,
        columnNumber: 20
      }
    }, "Submit"))));
  }

}

/* harmony default export */ __webpack_exports__["default"] = (TypeSearch);

/***/ }),

/***/ "./pages/namesearch.js":
/*!*****************************!*\
  !*** ./pages/namesearch.js ***!
  \*****************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_NameSearch_index__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../components/NameSearch/index */ "./components/NameSearch/index.js");
/* harmony import */ var _components_IdSearch_index__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../components/IdSearch/index */ "./components/IdSearch/index.js");
/* harmony import */ var _components_TypeSearch__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../components/TypeSearch */ "./components/TypeSearch/index.js");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! next/head */ "next/head");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_4__);
var _jsxFileName = "C:\\Users\\tallm\\Desktop\\DIG4503\\lab9\\pages\\namesearch.js";

var __jsx = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement;





const Home = () => {
  return __jsx("div", {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 11,
      columnNumber: 3
    }
  }, __jsx(next_head__WEBPACK_IMPORTED_MODULE_4___default.a, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 12,
      columnNumber: 10
    }
  }, __jsx("title", {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 13,
      columnNumber: 9
    }
  }, "This is the Name Search page!")), __jsx(_components_NameSearch_index__WEBPACK_IMPORTED_MODULE_1__["default"], {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 16,
      columnNumber: 3
    }
  }), __jsx("h2", {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 18,
      columnNumber: 5
    }
  }, "Reporting"), __jsx("div", {
    id: "reportingArea",
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 19,
      columnNumber: 5
    }
  }));
};

/* harmony default export */ __webpack_exports__["default"] = (Home);

/***/ }),

/***/ 5:
/*!***********************************!*\
  !*** multi ./pages/namesearch.js ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! C:\Users\tallm\Desktop\DIG4503\lab9\pages\namesearch.js */"./pages/namesearch.js");


/***/ }),

/***/ "next/head":
/*!****************************!*\
  !*** external "next/head" ***!
  \****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("next/head");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react");

/***/ })

/******/ });
//# sourceMappingURL=namesearch.js.map